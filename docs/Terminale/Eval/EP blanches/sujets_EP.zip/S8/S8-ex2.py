class Rectangle:

    def __init__(self,largeur,longueur):
        self.largeur = largeur
        self.longueur = longueur
    
