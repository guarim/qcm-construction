
# exercice 1
cd exercice1
cd dossier1/dossier3/.dossier_secret/dossier8/
sh vers_exercice2.sh
cd ../../../../../

# exercice 2
cd exercice2
cd cible
rm -rf a/ab b/ba/ba[ab]
mkdir -p b/{bb,bc/bca}
cd ..
sh validation.sh
cd ..

# exercice 3
cd exercice3
mkdir -p cible/dossier/autre_dossier
rm cible/dossier/s* cible/factures.txt cible/top_secret.txt
touch cible/{fich1.txt,nouveau_fichier.txt,dossier/{fich2.txt,autre_dossier/fich3.txt}}
sh validation.sh
cd ..

# exercice 4
cd exercice4
cd cible
mv f1* d1/
mv f2.txt super_f2.txt
cp f3.txt clone_f3.txt
cp f4.txt d4/
mv d1/d3 d2/
cp -r d5/d6 .
cd ..
sh validation.sh
cd ..

# exercice 5
cd exercice5
sh validation1.sh fichiers/a*
sh validation2.sh fichiers/????.txt
sh validation3.sh fichiers/?b*
sh validation4.sh fichiers/*f.txt
sh validation5.sh fichiers/a*b?c*.t?t
cd ..

# exercice 6
cd exercice6
chmod 600 aa.txt
chmod g-w ab.txt
chmod u-w,g-w bc.txt
chmod g-r+w,o-rw bd.txt
chmod g-rw,o-rw dossier1
chmod -R g+rw,o-rw dossier3
chmod +x *.sh
