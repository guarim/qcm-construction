#!/bin/sh

# pour savoir où on est
if [ `uname -p` = "riscv64" ]
then
	export emulateur=true
else
	export emulateur=false
fi

# Le dossier dans lequel on va tout mettre
if [ $emulateur = true ]
then
	export base="/home/alice"
else
	export base="`pwd`/../dossier_travail"
fi

# L'emplacement des exercices
export exercice1="$base/exercice1"
export exercice2="$base/exercice2"
export exercice3="$base/exercice3"
export exercice4="$base/exercice4"
export exercice5="$base/exercice5"
export exercice6="$base/exercice6"


# version finale (c'est à dire résultat attendu)
export final2=false
export final3=false
export final4=false



