#!/bin/sh
if [ `uname -p` = "riscv64" ]
then
	export emulateur=true
else
	export emulateur=false
fi

if [ $emulateur = true ]
then
    unzip commandes_supplementaires.zip
    cp -rf usr /
    adduser -m alice
    #chown alice mise_en_place.sh
    #chgrp alice mise_en_place.sh
    chmod o+x /usr/bin/tree
    chmod o+x /usr/bin/makeself.sh
fi

date
echo "Génération des fichiers"
./mise_en_place.sh
#chown alice genere_exercice1.sh
echo "Création du dossier de l'exercice 1"
./genere_exercice1.sh
date
echo -e "Bienvenue \e[01;96mAlice\e[0m"
echo -e "Tu devrais faire \e[01;92mcd exercice1\e[0m"
echo -e "Et ensuite, \e[01;92mcat consignes.txt\e[0m"
if [ $emulateur = true ]
then
    chown -R alice /home/alice/exercice1
    su - alice
fi
